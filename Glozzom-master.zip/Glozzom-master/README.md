# Glozzom
Multi Page Business Style Theme - Udemy Bootstrap 4 Beta course project

This project dervies from a Udemy Course: https://www.udemy.com

Course page: https://www.udemy.com/bootstrap-4-from-scratch-with-5-projects/

The Course is called Bootstrap 4 From Scratch With 5 Projects, by Brad Traversy of Traversy Media

Website Features:

- Carousel Slider with multiple background images

- Slick Slider for the testimonials area

- Light Box component for a mini gallery area
